import React from 'react';
import { NavLink } from 'react-router-dom';


function Mynavbar() {
  return (
    <>
    <nav class='navbar bg-dark'>
    <div class="container">
         <h1 class='logo lg-heading text-light'>WT</h1>
         <ul class='nav-items'>
         <li className="nav-item">
            <NavLink to="/" exact activeClassName="active-link">Home</NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/about" activeClassName="active-link">About</NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/contact" activeClassName="active-link">Contact</NavLink>
          </li>
            
            
         </ul>
    </div>
</nav>
    </>
  );
}

export default Mynavbar;
