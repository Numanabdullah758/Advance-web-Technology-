import React from "react";
import { NavLink } from "react-router-dom";


function Header() {
  return (
    <>
      <header class="header">
        <nav className="navbar">
          <div className="container">
            <h1 className="logo lg-heading text-light">WT</h1>
            <ul className="nav-items">
              <li className="nav-item">
                <NavLink to="/" exact activeClassName="active-link">
                  Home
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink to="/about" activeClassName="active-link">
                  About
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink to="/contact" activeClassName="active-link">
                  Contact
                </NavLink>
              </li>
            </ul>
          </div>
        </nav>

        <div class="header-content">
          <h1 class="lg-heading text-light main-heading">travel the world</h1>
          <p class="text-light">
            travel the world, experience the greateness, it's the best gift
            given by nature
          </p>
          <a href="#" class="btn btn-primary text-red md-heading">
            Explore Places
          </a>
        </div>
      </header>
    </>
  );
}

export default Header;
