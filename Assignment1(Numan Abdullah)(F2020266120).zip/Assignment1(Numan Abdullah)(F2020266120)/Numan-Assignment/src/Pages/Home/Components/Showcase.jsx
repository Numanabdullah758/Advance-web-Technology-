import React from "react";
import img1 from "../../../../public/images/showcase-photo1.jpg";
import img3 from "../../../../public/images/showcase-photo3.jpg";
import { NavLink } from "react-router-dom";

function Showcase() {
  return (
    <>
      <section className="showcase">
        <div className="container">
          <div className="row row1">
            <div className="img-box">
              <img src={img3} alt="Image Description" />
            </div>
            <div className="text-box">
              <h2 className="lg-heading text-black">DEGANVY, U.K</h2>
              <p className="text-gray">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                Impedit incidunt nulla a corporis eveniet pariatur maiores, id
                quis, totam dolore praesentium facere consequatur rem, fuga
                minus! Rerum, dolorem praesentium. Nemo?
              </p>
              <NavLink to="/about" className="btn btn-secondary">
                More
              </NavLink>
            </div>
          </div>
          <div className="row row2">
            <div className="img-box">
              <img src={img1} alt="Image Description" />
            </div>
            <div className="text-box">
              <h2 className="lg-heading text-black">DESERT, EGYPT</h2>
              <p className="text-gray">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                Maiores, amet ratione, quas laborum porro, explicabo vero ipsum
                laudantium nesciunt eos illum pariatur obcaecati fugiat
                asperiores nulla adipisci. Porro, atque itaque.
              </p>
              <NavLink to="/about" className="btn btn-secondary">
                More
              </NavLink>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Showcase;
