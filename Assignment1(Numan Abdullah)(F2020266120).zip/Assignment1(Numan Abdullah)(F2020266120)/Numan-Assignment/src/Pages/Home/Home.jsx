import React from "react";
import Myheader from './Components/Header'
import Myshowcase from './Components/Showcase'
import Myfeatures from './Components/Features'
import Myfooter from '../../Components/Footer';

function Home() {
  return (
    <>
      <Myheader />
      <Myshowcase />
      <Myfeatures />
      <Myfooter />
    </>
  );
}

export default Home;
