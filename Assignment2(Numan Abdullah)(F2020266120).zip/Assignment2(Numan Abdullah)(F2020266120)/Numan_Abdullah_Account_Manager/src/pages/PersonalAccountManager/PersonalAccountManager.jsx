import React from "react";

// components
import AccountManager from "../../components/AccountManager/AccountManager"

const PersonalAccountManager = () => {
 
  return (
    <AccountManager>
    </AccountManager>
  );
};

export default PersonalAccountManager;