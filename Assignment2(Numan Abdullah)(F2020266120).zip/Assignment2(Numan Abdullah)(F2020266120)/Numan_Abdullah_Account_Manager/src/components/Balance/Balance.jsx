import React from "react";
import { useAccountContext } from "../../context/accountContext";

const Balance = () => {
  const AccountData = useAccountContext();
  // console.log(AccountData);
  const {account} = AccountData;

  return (
    <>
      <h4>Your Balance</h4>
      <h1 id="balance">${account.balance}.00</h1>
    </>
  );
};

export default Balance;